package areas;

import animals.Animal;

import java.util.ArrayList;

public class Aquarium extends Area implements IArea{

    public Aquarium(int maximum) {
        super(maximum);
    }

}

package areas;

import animals.Animal;

import java.util.ArrayList;

public class Aquarium extends Area implements IArea{

    int id;


    public Aquarium(int maximum) {
        super(maximum);
       listOfInhabitants = new ArrayList<>();
        this.maximum = maximum;
    }


    @Override
    public void addAnimalToArea(Animal animal) {
         listOfInhabitants.add(animal);
    }

    @Override
    public boolean IsCompatibleWithInhabitants(Animal animal) {
        for(Animal list : listOfInhabitants) {
            if(!animal.isCompatibleWith(list)) {
                return false;
            }
        }
        return true;
    }

    //@Override
    //    public String getAnimalFromArea() {
    //        for(Animal list : listOfInhabitants) {
    //            System.out.println(list.getNickname());
    //        }
    //        return null;
    //    }
}

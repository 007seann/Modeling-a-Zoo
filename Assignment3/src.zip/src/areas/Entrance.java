package areas;

import animals.Animal;

import java.util.ArrayList;

public class Entrance extends Area implements IArea {


    public Entrance() {
        super();
    }

}

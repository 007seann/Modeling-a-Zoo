package areas;

import animals.Animal;

import java.util.ArrayList;

public class PicnicArea extends Area implements IArea {

    int id;

    public PicnicArea() {
        super();
    }

    @Override
    public void addAnimalToArea(Animal animal) {

    }

    @Override
    public boolean isFull() {
        return false;
    }

    @Override
    public boolean IsCompatibleWithInhabitants(Animal animal) {
        return false;
    }
}
/*

    @Override
    public String getAnimalFromArea() {
        return null;
    }

 */

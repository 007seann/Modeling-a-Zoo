package areas;

import animals.Animal;

import java.util.ArrayList;

public class Cage extends Area implements IArea {

    public Cage(int maximum) {
        super(maximum);
    }


}



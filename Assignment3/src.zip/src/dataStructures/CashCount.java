package dataStructures;

import zoo.Zoo;

public class CashCount implements ICashCount{

    int countOf20poundsNote;
    int countOf10poundsNote;
    int countOf5poundsNote;
    int countOf2poundsNote;
    int countOf1poundsNote;
    int countOf50p;
    int countOf20p;
    int countOf10p;

    public CashCount() {
        countOf20poundsNote = 0;
        countOf10poundsNote = 0;
        countOf5poundsNote = 0;
        countOf2poundsNote = 0;
        countOf1poundsNote = 0;
        countOf50p = 0;
        countOf20p = 0;
        countOf10p = 0;
    }

    public static CashCount add(CashCount cashCount, CashCount cashInserted) {
        CashCount c = new CashCount();
        c.countOf20poundsNote = cashCount.countOf20poundsNote + cashInserted.countOf20poundsNote;
        c.countOf10poundsNote = cashCount.countOf10poundsNote + cashInserted.countOf10poundsNote;
        c.countOf5poundsNote = cashCount.countOf5poundsNote + cashInserted.countOf5poundsNote;
        c.countOf2poundsNote = cashCount.countOf2poundsNote + cashInserted.countOf2poundsNote;
        c.countOf1poundsNote = cashCount.countOf1poundsNote + cashInserted.countOf1poundsNote;
        c.countOf50p = cashCount.countOf50p + cashInserted.countOf50p;
        c.countOf20p = cashCount.countOf20p + cashInserted.countOf20p;
        c.countOf10p = cashCount.countOf10p + cashInserted.countOf10p;

        return c;
    }
/*
    public static CashCount returnChange(CashCount cashInserted) {
        Zoo z = new Zoo();
        CashCount c = new CashCount();
        c.countOf20poundsNote = cashInserted.countOf20poundsNote - z.getEntrancePounds().cashInserted;
        c.countOf10poundsNote = cash
        ...
    }

 */
/*
    int getValue() {

    }


 */
    /*
    public void add(CashCount right) {
        this.coin1 = this.coin1 + right.coin1;
        this.coin2 = this.coin2 + right.coin2;
        ...
        }

        // totalMoney += cashInserter;
        -> totalMoney.add(cashInserter);
     */

    @Override
    public void setNrNotes_20pounds(int noteCount) {
        countOf20poundsNote = noteCount;
    }

    @Override
    public void setNrNotes_10pounds(int noteCount) {
        countOf10poundsNote = noteCount;
    }

    @Override
    public void setNrNotes_5pounds(int noteCount) {
        countOf5poundsNote = noteCount;
    }

    @Override
    public void setNrCoins_2pounds(int coinCount) {
        countOf2poundsNote = coinCount;
    }

    @Override
    public void setNrCoins_1pound(int coinCount) {
        countOf1poundsNote = coinCount;
    }

    @Override
    public void setNrCoins_50p(int coinCount) {
        countOf50p = coinCount;
    }

    @Override
    public void setNrCoins_20p(int coinCount) {
        countOf20p = coinCount;
    }

    @Override
    public void setNrCoins_10p(int coinCount) {
        countOf10p = coinCount;
    }

    @Override
    public int getNrNotes_20pounds() {
        return countOf20poundsNote;
    }

    @Override
    public int getNrNotes_10pounds() {
        return countOf10poundsNote;
    }

    @Override
    public int getNrNotes_5pounds() { return countOf5poundsNote; }

    @Override
    public int getNrCoins_2pounds() {
        return countOf2poundsNote;
    }

    @Override
    public int getNrCoins_1pound() {
        return countOf1poundsNote;
    }

    @Override
    public int getNrCoins_50p() {
        return countOf50p;
    }

    @Override
    public int getNrCoins_20p() {
        return countOf20p;
    }

    @Override
    public int getNrCoins_10p() {
        return countOf10p;
    }
}
